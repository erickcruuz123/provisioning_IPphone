#!/usr/bin/env bash
# =====================================================================
#  instalar_servidor.sh - monta o servidor de provisionamento em um
#  Debian 12 / Ubuntu 22.04+ limpo (rodar como root).
#
#  Uso:  sudo ./instalar_servidor.sh [--rede 192.168.0.0/16] [--sem-ftp] [--sem-painel]
#
#  Instala:  TFTP (tftpd-hpa) + HTTP (nginx) + FTP anônimo só-leitura (vsftpd),
#            os três servindo a mesma pasta /srv/provisionamento. Assim o
#            telefone funciona com qualquer protocolo configurado nele.
#            --sem-ftp  pula o FTP.
#  Painel web de gerenciamento na porta 8080 (usuário admin; a senha
#  aparece no fim da instalação). --sem-painel pula esta parte.
#  Copia os scripts para /opt/provisionamento e cria o comando
#  "provisiona" em /usr/local/bin.
#  NÃO mexe no DHCP da rede: veja a pasta dhcp/ e o README.
# =====================================================================
set -euo pipefail
REDE="192.168.0.0/16"; FTP=sim; PAINEL=sim
while [ $# -gt 0 ]; do
  case "$1" in
    --rede) REDE="$2"; shift 2 ;;
    --ftp)  FTP=sim; shift ;;          # mantido por compatibilidade (já é o padrão)
    --sem-ftp) FTP=nao; shift ;;
    --sem-painel) PAINEL=nao; shift ;;
    *) echo "opção desconhecida: $1" >&2; exit 1 ;;
  esac
done
[ "$(id -u)" -eq 0 ] || { echo "rode como root (sudo)" >&2; exit 1; }
ORIGEM="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
PROV_DIR=/srv/provisionamento
APP_DIR=/opt/provisionamento

echo ">> Instalando pacotes"
export DEBIAN_FRONTEND=noninteractive
apt-get update -q
apt-get install -y -q tftpd-hpa nginx python3 curl
[ "$FTP" = sim ] && apt-get install -y -q vsftpd

echo ">> Copiando scripts para $APP_DIR"
mkdir -p "$APP_DIR" "$PROV_DIR"
if [ "$ORIGEM" != "$APP_DIR" ]; then
  # Não sobrescreve configuração, templates importados nem a planilha de ramais.
  cp -n "$ORIGEM"/provisiona.conf "$ORIGEM"/modelos.conf "$APP_DIR"/ 2>/dev/null || true
  cp -f "$ORIGEM"/*.sh "$ORIGEM"/ramais_exemplo.csv "$APP_DIR"/
  mkdir -p "$APP_DIR/templates" "$APP_DIR/dhcp"
  cp -n "$ORIGEM"/templates/* "$APP_DIR/templates/" 2>/dev/null || true
  cp -f "$ORIGEM"/dhcp/* "$APP_DIR/dhcp/" 2>/dev/null || true
  if [ -d "$ORIGEM/painel" ]; then
    mkdir -p "$APP_DIR/painel"
    cp -f "$ORIGEM"/painel/painel.py "$ORIGEM"/painel/index.html "$APP_DIR/painel/"
  fi
  [ -f "$ORIGEM/README.md" ] && cp -f "$ORIGEM/README.md" "$APP_DIR/"
fi
chmod 755 "$APP_DIR"/*.sh
chmod 600 "$APP_DIR/provisiona.conf"
ln -sf "$APP_DIR/provisiona.sh" /usr/local/bin/provisiona
for s in "$APP_DIR"/create_modelo_*.sh; do ln -sf "$s" "/usr/local/bin/$(basename "$s")"; done
chmod 755 "$PROV_DIR"

echo ">> Criando usuário de serviço 'provisiona' (dono dos arquivos)"
if ! id provisiona >/dev/null 2>&1; then
  useradd --system --home-dir "$APP_DIR" --no-create-home --shell /usr/sbin/nologin provisiona
fi
# adm/systemd-journal: para o painel ler os logs de download (nginx e TFTP)
for g in adm systemd-journal; do getent group "$g" >/dev/null && usermod -aG "$g" provisiona; done
chown -R provisiona:provisiona "$APP_DIR" "$PROV_DIR"

echo ">> Configurando TFTP (porta 69/udp)"
cat > /etc/default/tftpd-hpa <<CONF
TFTP_USERNAME="tftp"
TFTP_DIRECTORY="$PROV_DIR"
TFTP_ADDRESS="0.0.0.0:69"
# --ipv4: sem isso o tftpd-hpa não sobe em servidores com IPv6 desativado.
# -v -v registra no syslog cada arquivo pedido (útil para descobrir o nome
# exato que cada modelo procura: journalctl -u tftpd-hpa -f)
TFTP_OPTIONS="--secure --ipv4 -v -v"
CONF
systemctl enable --now tftpd-hpa
systemctl restart tftpd-hpa

echo ">> Configurando HTTP (porta 80)"
cat > /etc/nginx/sites-available/provisionamento <<CONF
server {
    listen 80 default_server;
    server_name _;
    root $PROV_DIR;
    autoindex off;
    access_log /var/log/nginx/provisionamento.log;

    # Os arquivos têm senha SIP: só a rede dos telefones pode baixar.
    allow $REDE;
    allow 127.0.0.1;
    deny all;

    location ~ /\. { deny all; }
    location / { try_files \$uri =404; default_type text/plain; }
}
CONF
rm -f /etc/nginx/sites-enabled/default
ln -sf /etc/nginx/sites-available/provisionamento /etc/nginx/sites-enabled/provisionamento
nginx -t
systemctl enable --now nginx
systemctl reload nginx

if [ "$FTP" = sim ]; then
  echo ">> Configurando FTP anônimo só-leitura (porta 21)"
  cp -n /etc/vsftpd.conf /etc/vsftpd.conf.orig 2>/dev/null || true
  cat > /etc/vsftpd.conf <<CONF
listen=YES
listen_ipv6=NO
anonymous_enable=YES
anon_root=$PROV_DIR
no_anon_password=YES
local_enable=NO
write_enable=NO
anon_upload_enable=NO
anon_mkdir_write_enable=NO
dirlist_enable=NO
xferlog_enable=YES
pasv_min_port=40000
pasv_max_port=40100
secure_chroot_dir=/var/run/vsftpd/empty
xferlog_std_format=YES
xferlog_file=/var/log/vsftpd-provisionamento.log
CONF
  # o painel lê este log para mostrar downloads por FTP
  touch /var/log/vsftpd-provisionamento.log
  chown root:adm /var/log/vsftpd-provisionamento.log
  chmod 640 /var/log/vsftpd-provisionamento.log
  systemctl enable --now vsftpd
  systemctl restart vsftpd
fi

SENHA_MSG=""
if [ "$PAINEL" = sim ]; then
  echo ">> Configurando painel web (porta 8080)"
  if [ ! -f "$APP_DIR/painel.senha" ]; then
    SENHA_MSG="$(runuser -u provisiona -- python3 "$APP_DIR/painel/painel.py" --gerar-senha)"
  fi
  cat > /etc/systemd/system/provisiona-painel.service <<CONF
[Unit]
Description=Painel web do servidor de provisionamento
After=network-online.target

[Service]
User=provisiona
Group=provisiona
Environment=PAINEL_PORTA=8080
ExecStart=/usr/bin/python3 $APP_DIR/painel/painel.py
Restart=always
NoNewPrivileges=yes
PrivateTmp=yes
ProtectSystem=strict
ProtectHome=yes
ReadWritePaths=$APP_DIR $PROV_DIR

[Install]
WantedBy=multi-user.target
CONF
  systemctl daemon-reload
  systemctl enable --now provisiona-painel
  systemctl restart provisiona-painel
fi

if command -v ufw >/dev/null && ufw status | grep -q active; then
  echo ">> Liberando portas no ufw para $REDE"
  ufw allow from "$REDE" to any port 69 proto udp
  ufw allow from "$REDE" to any port 80 proto tcp
  [ "$FTP" = sim ] && ufw allow from "$REDE" to any port 21,40000:40100 proto tcp
  [ "$PAINEL" = sim ] && ufw allow from "$REDE" to any port 8080 proto tcp
fi

IP="$(hostname -I | awk '{print $1}')"
cat <<FIM

Pronto. Servidor de provisionamento em $IP
  TFTP: tftp://$IP/        HTTP: http://$IP/$( [ "$FTP" = sim ] && echo "        FTP: ftp://$IP/" )
  Arquivos:      $PROV_DIR
  Scripts:       $APP_DIR   (comando: provisiona)
$( [ "$PAINEL" = sim ] && echo "  Painel web:    http://$IP:8080/   usuário admin" )
$( [ -n "$SENHA_MSG" ] && echo "  $SENHA_MSG   (anote; trocar: sudo -u provisiona python3 $APP_DIR/painel/painel.py --definir-senha)" )

Próximos passos:
  1. Informe o IP do PABX no painel (Configurações) ou em $APP_DIR/provisiona.conf
  2. Aponte o DHCP da rede para este servidor (opção 66 = $IP). Veja $APP_DIR/dhcp/
  3. provisiona gerar tip235g 24fd0d350b0d 3310 4480 DIOMAI-CT
FIM

echo ">> Testando os serviços"
sleep 1
"$APP_DIR/provisiona.sh" testar || true
