#!/usr/bin/env bash
# Compatível com o script antigo:
#   create_modelo_125.sh <mac> <ramal> <senha> <nome>
#   ex.: create_modelo_125.sh 24fd0d350b0d 3310 4480 DIOMAI-CT
[ $# -eq 4 ] || { echo "uso: $0 <mac> <ramal> <senha> <nome>" >&2; exit 1; }
exec "$(dirname "$(readlink -f "$0")")/provisiona.sh" gerar tip125 "$@"
